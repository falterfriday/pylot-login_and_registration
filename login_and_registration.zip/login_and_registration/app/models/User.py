""" 
    This is the MODEL
"""
from system.core.model import Model
import re
class User(Model):
    def __init__(self):
        super(User, self).__init__()
    
    def get_all_users(self):
        return self.db.query_db("SELECT * FROM users")   
    

    def create_user(self, info):
        EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9\.\+_-]+@[a-zA-Z0-9\._-]+\.[a-zA-Z]*$')
        NAME_REGEX = re.compile(r'^[a-zA-Z]*$')
        errors = []
        if not info['first_name']:
            errors.append('First name cannot be blank')
        elif len(info['first_name']) < 2:
            errors.append('First name must be at least 2 characters long')
        elif not NAME_REGEX.match(info['first_name']):
            errors.append('First name format must be valid!')
        if not info['last_name']:
            errors.append('Last name cannot be blank')
        elif len(info['last_name']) < 2:
            errors.append('Last name must be at least 2 characters long')
        elif not NAME_REGEX.match(info['last_name']):
            errors.append('Last name format must be valid!')
        if not info['email']:
            errors.append('Email cannot be blank')
        elif not EMAIL_REGEX.match(info['email']):
            errors.append('Email format must be valid!')
        if not info['password']:
            errors.append('Password cannot be blank')
        elif len(info['password']) < 8:
            errors.append('Password must be at least 8 characters long')
        elif info['password'] != info['pw_confirmation']:
            errors.append('Passwords must match!')
        if errors:
            return {"status": False, "errors": errors}
        else:
            password = info['password']
            hashed_pw = self.bcrypt.generate_password_hash(password)
            create_query = "INSERT INTO users (first_name, last_name, email, pw_hash, created_at, updated_at) VALUES (:first_name, :last_name, :email, :pw_hash, NOW(), NOW() )"
            create_data = {'first_name': info['first_name'], 'last_name': info['last_name'], 'email': info['email'], 'pw_hash': hashed_pw}
            self.db.query_db(create_query,create_data)
            get_user_query = "SELECT * FROM users ORDER BY id DESC LIMIT 1"
            users = self.db.query_db(get_user_query)
            return { "status": True, "user": users[0] }

    def login_user(self, info):
        EMAIL_REGEX = re.compile(r'^[a-za-z0-9\.\+_-]+@[a-za-z0-9\._-]+\.[a-za-z]*$')
        errors = []
        if not info['email']:
            errors.append('Email cannot be blank')
        elif not EMAIL_REGEX.match(info['email']):
            errors.append('Email format must be valid!')
        if not info['password']:
            errors.append('Password cannot be blank')
        elif len(info['password']) < 8:
            errors.append('Password must be provided')
        if errors:
            return {"status": False, "errors": errors}
        else:
            password = info['password']
            user_query = "SELECT * FROM users WHERE email = :email LIMIT 1"
            user_data = {'email': info['email']}
            user = self.db.query_db(user_query, user_data)
            if user:
                if self.bcrypt.check_password_hash(user[0]['pw_hash'], password):
                    return { "status": True, "user": user[0] }
                else:
                    errors.append('Invalid login credentials!')
            else:
                    errors.append('Invalid login credentials!')
            return {"status": False, "errors": errors}
















